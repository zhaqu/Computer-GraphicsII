#pragma once

void Cylinder(glm::vec3 v1, glm::vec3 v2, float radius, ofMesh& mesh, glm::vec3 color = glm::vec3(0), int sides = 6);