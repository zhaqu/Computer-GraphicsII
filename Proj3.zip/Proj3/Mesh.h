#include <vector>
#include <iostream>
#include <fstream>
#include <glm/vec3.hpp>
#include <string.h>
#include <queue>
class HalfEdge;
class Face
{
public:
    HalfEdge* edge;
    int index;
    std::vector<HalfEdge* > face_Edges();
};

class Vertex
{
public:
    glm::vec3 pos;
    HalfEdge* edge;
    int index;
    int next_point[20] = {-1};
    std::vector<HalfEdge* > vertex_Edges();
};

class HalfEdge
{
public:
    HalfEdge* opposite;
    HalfEdge* next;
    Vertex* vert;
    Vertex* arrived;
    Face* face;  
    int index;
};



class Mesh
{
public:
    std::vector<Face* > face;
    std::vector<Vertex* > vertex;
    std::vector<HalfEdge* > half_edge;
    std::vector<HalfEdge* > boundary_edge;
    std::vector<std::vector<HalfEdge* > > Boundaries();
    void InsertVertex(float x, float y, float z, int index);
    void InsertFace();
    void BuildFromObj(); 
    std::vector<HalfEdge*> ShortestPath(Vertex* v_source, Vertex* v_target);
};
double point[50000][3];
int DFS_array[4000] = {-1};
bool DFS_color[4000] = {0};
int faces[50000][4];
int point_num = 0;
int faces_num = 0;
int bound_num = 0;
Mesh mesh;
