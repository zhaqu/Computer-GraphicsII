#include "Mesh.h"

void ObjScan(const char* name)
{
    std::ifstream file;
    file.open(name);   
    char buf[256], str[255], *p;
    while(!file.getline(buf, 255).eof())
    {
        p = strtok(buf, " ");
        if(buf[0] == 'v')
        {
            p = strtok(NULL, " ");
            point[point_num][0] = std::strtod(p,NULL);
            p = strtok(NULL, " ");
            point[point_num][1] = std::strtod(p, NULL);
            p = strtok(NULL, " ");
            point[point_num][2] = std::strtod(p, NULL);
            point_num += 1;
        }
        else if (buf[0] == 'f')
        {
            p = strtok(NULL, " ");
            faces[faces_num][0] = std::atoi(p);
            p = strtok(NULL, " ");
            faces[faces_num][1] = std::atoi(p);
            p = strtok(NULL, " ");
            faces[faces_num][2] = std::atoi(p);
            if(p = strtok(NULL, " "))
            {
                faces[faces_num][3] = std::atoi(p);
            }
            else
            {
                faces[faces_num][3] = 0;
            }
            
            
            faces_num += 1;
        }
    }
}

void Mesh::InsertVertex(float x, float y, float z, int index)
{
    mesh.vertex[index]->pos = {x, y, z};
    mesh.vertex[index]->index = index;
}

void Mesh::InsertFace()
{
    for (size_t i = 0; i < faces_num; i++)
    {
        if(faces[i][3]>0)
        {
            for (size_t j = 0; j < 4; j++)
            {
            {
            mesh.half_edge[4*i+j]->vert = mesh.vertex[faces[i][j]-1];
            mesh.half_edge[4*i+j]->index = 4*i+j;
            mesh.vertex[faces[i][j]-1]->edge = mesh.half_edge[4*i+j];

            mesh.face[i]->index = i;
            mesh.face[i]->edge = mesh.half_edge[4*i];
            mesh.half_edge[4*i+j]->face = mesh.face[i];

            int next = (j+1) % 4;
            mesh.half_edge[4*i+j]->next = mesh.half_edge[4*i+next];
            }
            }
        }
        else
        {
            for (size_t j = 0; j < 3; j++)
            {
            {
            mesh.half_edge[4*i+j]->vert = mesh.vertex[faces[i][j]-1];
            mesh.half_edge[4*i+j]->index = 4*i+j;
            mesh.vertex[faces[i][j]-1]->edge = mesh.half_edge[4*i+j];

            mesh.face[i]->index = i;
            mesh.face[i]->edge = mesh.half_edge[4*i];
            mesh.half_edge[4*i+j]->face = mesh.face[i];

            int next = (j+1) % 3;
            mesh.half_edge[4*i+j]->next = mesh.half_edge[4*i+next];
            }
            }
            mesh.half_edge[4*i+3]->vert = NULL;
            mesh.half_edge[4*i+3]->index = -1;
            mesh.half_edge[4*i+3]->face = mesh.face[i];
        }
        
        
    }

}

std::vector<HalfEdge* > Vertex::vertex_Edges()
{
    std::vector<HalfEdge*> temp_edges;
    HalfEdge* start_vertex = this->edge;
    HalfEdge* temp_vertex = start_vertex;
    do
    {
        if(temp_vertex->opposite)
        {
            temp_vertex = temp_vertex->opposite;
        }
        else{break;}
        temp_vertex = temp_vertex->next;
        temp_edges.push_back(temp_vertex);
    } while (temp_vertex != start_vertex);
    return temp_edges;
}

std::vector<std::vector<HalfEdge* > > Mesh::Boundaries()
{
    bool bon_include[bound_num] = {0};
    int vector_num = 0;
    std::vector<std::vector<HalfEdge* > > temp_edges;
    std::vector<HalfEdge* > single_bound;
    
    
    for (size_t i = 0; i < bound_num; i++)
    {
        
        if(bon_include[i]) {continue;};
        HalfEdge* start_edge = mesh.boundary_edge[i];
        HalfEdge* temp_edge = start_edge;
        do
        {
            temp_edge = temp_edge->next;
            single_bound.push_back(temp_edge);
            bon_include[temp_edge->index] = 1;
        } while (start_edge != temp_edge);
        vector_num+=1;
        temp_edges.push_back(single_bound);
        single_bound.clear();
    }
    return temp_edges;
    
}

void calValences()
{
    int number_val[20] = {0};
    for (size_t i = 0; i < point_num; i++)
    {
        number_val[mesh.vertex[i]->vertex_Edges().size()]+=1;
    }
    for (size_t i = 0; i < 20; i++)
    {
        if(number_val[i] != 0)
        {
            std::cout<<"valence-"<<i<<":"<<number_val[i]<<std::endl;
        }
    }
    std::cout<<std::endl;
}

void calBound()
{
    std::vector<std::vector<HalfEdge* > > temp_edges;
    temp_edges = mesh.Boundaries();
    std::cout<<"length of mesh boundaries:"<<std::endl;
    int number[500] = {0};
    for (std::vector<std::vector<HalfEdge* > >::iterator it = temp_edges.begin(); it != temp_edges.end(); it++)
    {
        number[it->size()]+=1;
    }
    bool report = 0;
    for (size_t i = 0; i < 500; i++)
    {
        if(number[i] != 0)
        {
            std::cout<<"length-"<<i<<":"<<number[i]<<std::endl;
            report = 1;
        }
    }
    if(report == 0) std::cout<<"none"<<std::endl;
    std::cout<<std::endl;
}

std::vector<HalfEdge*> Face::face_Edges()
{
    std::vector<HalfEdge*> temp_edges;
    HalfEdge* start_face = this->edge;
    HalfEdge* temp_face = start_face;
    do
    {
        temp_face = temp_face->next;
        temp_edges.push_back(temp_face);
    } while (start_face != temp_face);
    return temp_edges;
}

void calDegree()
{
    int num_degree[20] = {0};
    for (size_t i = 0; i < faces_num; i++)
    {
        num_degree[mesh.face[i]->face_Edges().size()]+=1;
    }

    for (size_t i = 0; i < 20; i++)
    {
        if(num_degree[i] != 0)
        {
            std::cout<<"degree-"<<i<<":"<<num_degree[i]<<std::endl;
        }
    }
    std::cout<<std::endl;
}

void Mesh::BuildFromObj()
{
    int ecount = 4*faces_num;
    mesh.face.reserve(faces_num);
    mesh.vertex.reserve(point_num);
    mesh.half_edge.reserve(ecount);
    mesh.boundary_edge.reserve(ecount);

    for (size_t i = 0; i < point_num; i++)
    {
        Vertex* temp_b = new Vertex;
        temp_b->pos = {-1, -1, -1};
        temp_b->edge = NULL;
        temp_b->index = -1;
        mesh.vertex.push_back(temp_b);
    }
    for (size_t i = 0; i < faces_num; i++)
    {
        Face* temp = new Face;
        temp->edge = NULL;
        temp->index = -1;
        mesh.face.push_back(temp);
    }
    for (size_t i = 0; i < ecount; i++)
    {
        HalfEdge* temp = new HalfEdge;
        temp->face = NULL;
        temp->next = NULL;
        temp->opposite = NULL;
        temp->vert = NULL;
        temp->index = -1;
        mesh.half_edge.push_back(temp);
    }
    for (size_t i = 0; i < point_num; i++)
    {
        InsertVertex(point[i][0], point[i][1],point[i][2], i);
    }
    InsertFace();
    for (size_t i = 0; i < ecount; i++)
    {
        for (size_t j = i+1; j < ecount; j++)
        {
            Vertex* abegin = mesh.half_edge[i]->vert;
            if(!abegin) continue;
            Vertex* aend = mesh.half_edge[i]->next->vert;
            Vertex* bbegin = mesh.half_edge[j]->vert;
            if(!bbegin)continue;
            Vertex* bend = mesh.half_edge[j]->next->vert;
            if(abegin->index == bend->index && aend->index == bbegin->index)
            {
                mesh.half_edge[i]->opposite = mesh.half_edge[j];
                mesh.half_edge[i]->arrived = mesh.half_edge[j]->vert;
                mesh.half_edge[j]->opposite = mesh.half_edge[i];
                mesh.half_edge[j]->arrived = mesh.half_edge[i]->vert;
                break;
            }
        }
    }
    int boun_index = 0;
    for (size_t i = 0; i < ecount; i++)
    {
        if(!mesh.half_edge[i]->opposite && mesh.half_edge[i]->index>-1)
        {
            HalfEdge* boundary = new HalfEdge;
            boundary->face = NULL;
            boundary->index = boun_index;
            boun_index += 1;
            boundary->vert = mesh.half_edge[i]->next->vert;
            boundary->arrived = mesh.half_edge[i]->vert;
            boundary->opposite = mesh.half_edge[i];
            mesh.half_edge[i]->opposite = boundary;
            boundary->next = NULL;
            bound_num+=1;
            mesh.boundary_edge.push_back(boundary);
        }
    }
    for (size_t i = 0; i < bound_num; i++)
    {
        for (size_t j = 0; j < bound_num; j++)
        {
            if(boundary_edge[i]->arrived->index == boundary_edge[j]->vert->index)
            {
                boundary_edge[i]->next = boundary_edge[j];
            }
        }
    }
}

void Next_Point_constrtuct()
{
    
    for (size_t i = 0; i < point_num; i++)
    {
        HalfEdge* start_vertex = mesh.vertex[i]->edge;
        HalfEdge* temp_vertex = start_vertex;
        int j = 0;
        do
        {
        if(temp_vertex->opposite)
        {
            temp_vertex = temp_vertex->opposite;
            mesh.vertex[i]->next_point[j] = temp_vertex->vert->index;
            j++;
        }
        else{break;}
        temp_vertex = temp_vertex->next;
        } while (temp_vertex != start_vertex);
    }
    
    
}

void DFS(Vertex* v1, Vertex* v2)
{
    std::queue<int> Q;
    int index_v1 = v1->index;
    Q.push(index_v1);
    int index_temp;
    DFS_color[index_v1] = 1;
    DFS_array[index_v1] = 0;
    while(!Q.empty())
    {
        index_temp = Q.front();
        Q.pop();
        if(index_temp == v2->index)
        {
            break;
        }
        for(int i = 0; i< 20; i++)
        {
            int may_push = mesh.vertex[index_temp]->next_point[i];
            if(may_push>-1 && DFS_color[may_push] == 0)
            {
                DFS_array[may_push] = index_temp;
                DFS_color[may_push] = 1;
                Q.push(may_push);
            }
        }
    }
}

std::vector<HalfEdge*> Mesh::ShortestPath(Vertex* v_source, Vertex* v_target)
{
    DFS(v_source, v_target);
    std::vector<HalfEdge* > temp_edges;
    int record = v_target->index;
    temp_edges.push_back(v_target->edge);
    while(record > 0)
    {
        record = DFS_array[record];
        temp_edges.push_back(mesh.vertex[record]->edge);
    }
    return temp_edges;
}

void printPath(Vertex* v_source, Vertex* v_target)
{
    std::vector<HalfEdge* > temp_edges = mesh.ShortestPath(v_source, v_target);
    std::cout<<"The Path is"<<std::endl;
    for (size_t i = temp_edges.size()-2; i > 0; i--)
    {
        std::cout<<temp_edges[i]->vert->index<<"->";
    }
    std::cout<<temp_edges[0]->vert->index<<std::endl;
    
}

int main(int argc, char const *argv[])
{
    if(argc != 2) 
    {
        std::cout<<"error argument "<< argc<<std::endl;
        return 0;
    }
    const char* name = argv[argc-1];
    std::cout<<std::endl;
    ObjScan(name);
    mesh.BuildFromObj();
    //test();
    calValences();
    calDegree();
    calBound();
    if(name[0] == 'c')
    {
        Next_Point_constrtuct();
        printPath(mesh.vertex[1700], mesh.vertex[1778]);
    }
    return 0;
}
