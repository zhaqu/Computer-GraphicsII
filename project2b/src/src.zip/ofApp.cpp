#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	bunny.load("bunny.ply");
	bunny_shader.load("bunny.vert", "bunny.frag");
	sky.load("cube.ply");
	sky_shader.load("sky.vert", "sky.frag");
	cam.Zoom(3);
	translate_matrix = glm::translate(-bunny.getCentroid());
	rotate_matrix = glm::rotate(glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0))
		* glm::rotate(glm::radians(-90.0f), glm::vec3(1.0, 0.0, 0.0));
	model = rotate_matrix * translate_matrix;
	cube_map.load("nvlobby_front.jpg", "nvlobby_back.jpg", "nvlobby_right.jpg", "nvlobby_left.jpg", "nvlobby_top.jpg", "nvlobby_bottom.jpg");
	model_sky = glm::scale(glm::vec3(6.0, 6.0, 6.0));

}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
	ofEnableDepthTest();
	
	sky_shader.begin();
	glDepthFunc(GL_LEQUAL);
	sky_shader.setUniformMatrix4f("model", model_sky);
	sky_shader.setUniformMatrix4f("view", cam.ViewMatrix());
	sky_shader.setUniformMatrix4f("projection", cam.ProjectionMatrix());
	sky_shader.setUniformTexture("envMap", cube_map.getTexture(), 0);
	sky.draw();
	sky_shader.end();
	
	bunny_shader.begin();
	glDepthFunc(GL_LESS);
	bunny_shader.setUniformMatrix4f("model", model);
	bunny_shader.setUniformMatrix4f("view", cam.ViewMatrix());
	bunny_shader.setUniformMatrix4f("projection", cam.ProjectionMatrix());
	bunny_shader.setUniformTexture("envMap", cube_map.getTexture(), 0);
	bunny.draw();
	bunny_shader.end();
}	
	

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
